<?php
namespace App\Http\Middleware;
use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
class EnsureRole
{
    public function handle(Request $request, Closure $next, string ...$roles): Response
    {
        $user = $request->user();
        if (!$user) return response()->json(['message' => 'Unauthenticated.'], 401);
        if (!in_array($user->role, $roles, true)) return response()->json(['message' => 'Forbidden: role tidak memiliki akses.'], 403);
        return $next($request);
    }
}
